This is a development version of 3dmigoto (optimized for Linux).

Original release from https://github.com/SilentNightSound/GI-Model-Importer.

This version of 3dmigoto is optimized for the "an anime game launcher" https://github.com/an-anime-team/an-anime-game-launcher.

If you have any questions or issues, please open an issue on the github page or send me a DM on discord (MrLGamer#8335)